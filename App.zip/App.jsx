import "./App.css";
import Title from "./Title.jsx";
import Product from "./product.jsx";

function App() {
    return (
      <>
        <Product/>
        <Product/>
        <Product/>
      </>
    ); 
}

export default App;
