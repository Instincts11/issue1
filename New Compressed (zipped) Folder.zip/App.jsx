import "./App.css";
import Title from "./Title.jsx";
import ProductTab from "./ProductTab.jsx";

function App() {
    return 
        <ProductTab/>; 
}

export default App;

