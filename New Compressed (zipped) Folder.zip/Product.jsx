function Product() {
    return (
        <div>
            <h3>product Title</h3>
            <h5>product Description</h5>
        </div>
    );
}
export default Product;

