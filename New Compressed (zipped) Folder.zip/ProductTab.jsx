import Product from "./Product.jsx";

function ProductTab() {
    return (
        <>
        <Product />
        <Product />
        </>
    );
} 
export default ProductTab;