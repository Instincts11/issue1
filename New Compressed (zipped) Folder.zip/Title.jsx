function Title() {
    return
     (
    <div> 
        <p>2*2={2*2}</p>
    </div>
     );
  }
  export default Title;